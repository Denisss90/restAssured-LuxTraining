package com.sqa.controller;

import com.sqa.model.post.Post;
import com.sqa.model.post.Posts;
import com.sqa.model.user.User;
import com.sqa.model.user.UserResponse;
import com.sqa.model.user.Users;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class PostsController extends GorestController {

}
