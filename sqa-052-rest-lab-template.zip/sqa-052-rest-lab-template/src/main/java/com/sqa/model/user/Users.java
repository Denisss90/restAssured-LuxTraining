package com.sqa.model.user;

import com.fasterxml.jackson.annotation.*;
import com.sqa.model.Meta;
import lombok.Data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Users {

}