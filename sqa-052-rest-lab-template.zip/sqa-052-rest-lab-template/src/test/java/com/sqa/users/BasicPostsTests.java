package com.sqa.users;

import com.sqa.controller.PostsController;
import com.sqa.controller.UsersController;
import com.sqa.model.post.Post;
import com.sqa.model.post.Posts;
import com.sqa.model.user.User;
import com.sqa.model.user.UserResponse;
import com.sqa.model.user.Users;
import com.sqa.utils.TestLogger;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BasicPostsTests implements TestLogger {

    public BasicPostsTests() {

    }

    /*
       01. Проверяем создание пользователя
    */
    @Test
    public void verifyCreatePostTest() {

    }

    /*
        02. Получаем публикацию пользователя
    */
    @Test
    public void verifyGetCreatedPostTest() {

    }

    /*
        03. Обновляем публикацию пользователя
    */
    @Test
    public void verifyPatchCreatedPostTest() {

    }

    /*
        04. Удаляем публикацию пользователя
    */
    @Test
    public void verifyDeletePostTest() {

    }
}

