package com.sqa.users;

import com.sqa.controller.UsersController;
import com.sqa.model.user.User;
import com.sqa.model.user.UserResponse;
import com.sqa.model.user.Users;
import com.sqa.utils.FileUtils;
import com.sqa.utils.TestLogger;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class BasicUsersTests implements TestLogger {


    public BasicUsersTests() {

    }

     /*
        01. Проверяем создание пользователя
     */
     @Test
     public void verifyCreateUserTest() {

     }

    /*
        02. Получаем пользователя по емейлу
    */
    @Test
    public void verifyGetCreatedUserTest() {

    }

    /*
        03. Обновляем пользователя по емейлу
    */
    @Test
    public void verifyPatchCreatedUserTest() {

    }

    /*
        04. Удаляем пользователя по емейлу
    */
    @Test
    public void verifyDeleteUserTest() {

    }
}

