package com.sqa.github;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sqa.model.github.Issue;
import com.sqa.services.GitHubService;
import com.sqa.services.GorestService;
import com.sqa.utils.TestLogger;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.Test;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class RetrofitDemoTest implements TestLogger {

    private Retrofit retrofitGit;
    private Retrofit retrofitGorest;
    private GitHubService gitHubService;
    private GorestService gorestService;
    private static final String GIT_HUB_URL = "https://api.github.com/";
    private static final String GOREST_URL = "https://gorest.co.in/";

    private String issueTitle = String.format("issue %s", RandomStringUtils.randomAlphabetic(5));
    private String issueDescription = "Description of new issue";

    public RetrofitDemoTest() {

    }

    /*
        01. Проверяем, что приходит 200 код в ответ на простой GET
    */
    @Test
    public void verifyHealthcheckTest() throws IOException {

    }

    /*
        02. Проверяем, что приходит непустое тело ответа на простой GET
    */
    @Test
    public void verifyDefunktBodyTest() throws IOException {

    }

    /*
        03. Проверяем, что тело ответа содержит поле, равное значению
    */
    @Test
    public void verifyIssuesContainTest() throws IOException {

    }

    /*
        04. Проверяем, что тело ответа содержит поле после авторизации
    */
    @Test
    public void verifyIssuesAuthorized() throws IOException {

    }

    /*
        05. Проверяем, что тело ответа содержит ошибку и 403 код
    */
    @Test
    public void verifyIssuesNoUserAgent() throws IOException {

    }

    /*
        06. Проверяем, что ишью публикуется
    */
    @Test
    public void verifyPostIssues() throws IOException {

    }

    /*
        07. Проверяем, что тело ответа содержит ошибку и 403 код
    */
    @Test
    public void verifyPostIssuesUrlParam() throws IOException {

    }

    /*
        08. Проверяем, что ишью публикуется (тело запроса в POJO)
    */
    @Test
    public void verifyPostPojo() throws IOException {

    }

    /*
        09. Проверяем, что ишью публикуется (тело запроса в Map)
    */
    @Test
    public void verifyPostMap() throws IOException {

    }

}
