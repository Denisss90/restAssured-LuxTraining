package com.sqa.services;

import com.sqa.model.github.Issue;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.List;
import java.util.Map;

public interface GitHubService {

}
